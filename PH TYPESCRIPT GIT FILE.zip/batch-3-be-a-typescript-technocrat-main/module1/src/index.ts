let course: string = "Next level web development";
console.log(course);
